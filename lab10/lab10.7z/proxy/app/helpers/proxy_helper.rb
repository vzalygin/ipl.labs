# frozen_string_literal: true

module ProxyHelper
end
